export interface CampgroundItem{
    campgroundId:string
    campgroundName:string
    checkInDate:string
    checkOutDate:string
}