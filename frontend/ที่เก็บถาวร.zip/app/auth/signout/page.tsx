import SignOutForm from "@/components/SignOutForm"

export default function SignOut(){
    return (
        <div>
            <SignOutForm/>
        </div>
    )
}