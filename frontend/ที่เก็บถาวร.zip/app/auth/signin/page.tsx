import SignInForm from "@/components/SignInForm"

export default function Login(){
    return (
        <div>
            <SignInForm/>
        </div>
    )
}