import NextAuth, { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        // Make a POST request to your login API
        console.log("CREDEN", credentials);
        const res = await fetch("http://localhost:5000/api/v1/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: credentials?.email,
            password: credentials?.password,
          }),
        });

        if (!res.ok) {
          throw new Error("Invalid login credentials");
        }

        // Parse the API response
        const data = await res.json();

        // Return the user object to be embedded in the session
        return {
          id: data._id,
          name: data.name,
          email: data.email,
          token: data.token,
        };
      },
    }),
  ],
  callbacks: {
    async session({ session, token, user }) {
      // Embed the user object directly into the session
      session.user = token;
      return session;
    },
    async jwt({ token, user }) {
      if (user) {
        // Transfer user details to the token
        token = { ...user }; // Replace token with user object
      }
      return token;
    },
  },
  secret: process.env.NEXTAUTH_SECRET, // Ensure this is set in .env
  debug: true, // Enable debug logs
};

export default NextAuth(authOptions);
