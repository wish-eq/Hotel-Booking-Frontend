// app/ClientLayout.tsx
"use client";

import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "./ThemeProvider";

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    // <SessionProvider>
    <ThemeProvider>{children}</ThemeProvider>
    // </SessionProvider>
  );
}
